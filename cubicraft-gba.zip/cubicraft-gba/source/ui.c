/* ui.c - render del mundo, HUD y menus (inventario, fabricar, cofre, comercio, encantar, mapa...) */
#include "game.h"

int menu_kind;
Ent *trade_ent;
static int mcur, mtop, mpane, marg, mcat, msel2, mredraw, mrep;
static int cur2, top2; /* segundo panel (cofre) */

/* ------------------------------------------------------------------ texto */
void hud_clear(void) {
  for (int i = 0; i < 1024; i++) map_hud[i] = 0;
  map_dirty |= 8;
}
void hud_fill_panel(void) {
  for (int i = 0; i < 1024; i++) map_hud[i] = T_PANEL | (15 << 12);
  map_dirty |= 8;
}
static void hud_tile(int x, int y, int t) {
  if (x < 0 || y < 0 || x >= 30 || y >= 20) return;
  map_hud[y * 32 + x] = (u16)(t | (15 << 12));
  map_dirty |= 8;
}
void hud_text(int x, int y, const char *s) {
  while (*s && x < 30) {
    int c = (unsigned char)*s++;
    hud_tile(x++, y, (c >= 32 && c < 127) ? T_CHAR(c) : T_BLANK);
  }
}
static int itoa_(char *b, int v) {
  char t[12]; int n = 0, k = 0;
  if (v < 0) { b[k++] = '-'; v = -v; }
  if (v == 0) t[n++] = '0';
  while (v) { t[n++] = (char)('0' + v % 10); v /= 10; }
  while (n) b[k++] = t[--n];
  b[k] = 0;
  return k;
}
static void hud_num(int x, int y, int v) { char b[12]; itoa_(b, v); hud_text(x, y, b); }
static int slen(const char *s) { int n = 0; while (s[n]) n++; return n; }
static void padtext(char *dst, const char *s, int w) {
  int i = 0;
  while (s[i] && i < w) { dst[i] = s[i]; i++; }
  while (i < w) dst[i++] = ' ';
  dst[w] = 0;
}
static const char *ROMAN[4] = {"", "I", "II", "III"};

/* ------------------------------------------------------------------ mundo */
static int win_valid, wx0, wy0;
static int cam_x, cam_y;
static int scr_x, scr_y;
static int dark_tx, dark_ty, dark_t = -999, dark_amb = -1;

static void draw_cell(int tx, int ty) {
  int gs = 0, os = 0, hf = 0, vf = 0;
  if (tx >= 0 && ty >= 0 && tx < MW && ty < MH) {
    int i = tidx(tx, ty);
    gs = gfx_ground_slot(wg[i]);
    if (wg[i] == G_VOID) gs = 0;
    u8 o = wo[i];
    if (o) { u8 h2, v2; os = gfx_obj_slot(o, (u8)(wst[i] >> 7), (u8)(wst[i] & 3), &h2, &v2); hf = h2; vf = v2; }
  }
  mt_put(map_gnd, tx, ty, gs, 0, 0);
  mt_put(map_obj, tx, ty, os, hf, vf);
}
void render_tile(int x, int y) {
  if (!win_valid) return;
  if (x >= wx0 && x < wx0 + 16 && y >= wy0 && y < wy0 + 16) draw_cell(x, y);
  dark_t = -999;
}
void render_full_redraw(void) { win_valid = 0; dark_t = -999; }

static int clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }

static void apply_light(u8 *red, int cx0, int cy0, int lx, int ly, int r) {
  int y0 = ly - r < cy0 ? cy0 : ly - r, y1 = ly + r > cy0 + 11 ? cy0 + 11 : ly + r;
  int x0 = lx - r < cx0 ? cx0 : lx - r, x1 = lx + r > cx0 + 15 ? cx0 + 15 : lx + r;
  for (int y = y0; y <= y1; y++)
    for (int x = x0; x <= x1; x++) {
      int dx = x - lx, dy = y - ly, q = dx * dx + dy * dy, rd = 0;
      if (q <= r * r / 4) rd = 3; else if (q <= r * r * 9 / 16) rd = 2; else if (q <= r * r) rd = 1;
      u8 *p = &red[(y - cy0) * 16 + (x - cx0)];
      if (rd > *p) *p = (u8)rd;
    }
}
static void update_dark(int cx0, int cy0) {
  int amb = dark_level_ambient();
  int ptx = PTX(), pty = PTY();
  if (!(amb != dark_amb || ptx != dark_tx || pty != dark_ty || (int)game_time - dark_t > 30 || dark_t == -999)) return;
  dark_amb = amb; dark_tx = ptx; dark_ty = pty; dark_t = (int)game_time;
  static u8 red[16 * 12];
  for (int i = 0; i < 16 * 12; i++) red[i] = 0;
  if (amb > 0) {
    for (int y = cy0 - 6; y < cy0 + 18; y++)
      for (int x = cx0 - 6; x < cx0 + 22; x++) {
        if (x < 0 || y < 0 || x >= MW || y >= MH) continue;
        int i = tidx(x, y);
        u8 o = wo[i];
        int r = o ? BLK[o].light : 0;
        if (o == O_LAMP && !(wst[i] & 0x80)) r = 0;
        if (!r && wg[i] == G_LAVA && cur_dim != D_OVER) r = 3;
        if (r) apply_light(red, cx0, cy0, x, y, r);
      }
    apply_light(red, cx0, cy0, ptx, pty, P.t_night > 0 ? 9 : 4);
  }
  for (int cy = cy0; cy < cy0 + 12; cy++)
    for (int cx = cx0; cx < cx0 + 16; cx++) {
      int d = amb - red[(cy - cy0) * 16 + (cx - cx0)];
      if (d < 0) d = 0;
      u16 e = d ? (u16)((T_DARK1 + d - 1) | (15 << 12)) : 0;
      u16 *p = &map_dark[((cy & 15) * 2) * 32 + (cx & 15) * 2];
      p[0] = e; p[1] = e; p[32] = e; p[33] = e;
    }
  map_dirty |= 4;
}

static int spr_n;
static void spr(int x, int y, int slot, int size, int hf, int vf, int pri) { spr_n = oam_put(spr_n, x, y, slot, size, hf, vf, pri); }

static u8 hb_cache[9] = {255, 255, 255, 255, 255, 255, 255, 255, 255};

void ui_draw_hud(void) {
  /* corazones */
  for (int i = 0; i < 10; i++) {
    int v = P.hp - i * 2;
    hud_tile(i, 0, T_HEART + (v >= 2 ? 0 : v == 1 ? 1 : 2));
    int f = P.food - i * 2;
    hud_tile(20 + i, 0, T_FOOD + (f >= 2 ? 0 : f == 1 ? 1 : 2));
  }
  /* nivel y xp */
  hud_text(0, 1, "Nv");
  hud_num(2, 1, P.lvl);
  int fill = P.xp * 6 / xp_need(P.lvl);
  for (int i = 0; i < 6; i++) hud_tile(6 + i, 1, i < fill ? T_XPON : T_XPOFF);
  /* hora */
  {
    int hh = (int)((day_t * 24 / DAY_LEN + 6) % 24), mm = (int)((day_t * 24 * 60 / DAY_LEN) % 60);
    char b[8] = {(char)('0' + hh / 10), (char)('0' + hh % 10), ':', (char)('0' + mm / 10), (char)('0' + mm % 10), 0};
    hud_text(25, 1, b);
  }
  /* modo */
  if (P.mode == MODE_CREATIVE) hud_text(13, 1, "CREATIVO");
  else if (P.mode == MODE_HARD) hud_text(13, 1, "HARDCORE");
  /* jefe */
  if (boss && boss->type == M_DRAGON) {
    hud_text(8, 2, "DRAGON");
    int n = boss->hp * 12 / 60 + (boss->hp ? 1 : 0);
    for (int i = 0; i < 12; i++) hud_tile(15 + i, 2, i < n ? T_HEART : T_HEART + 2);
  }
  /* mensaje */
  if (msg_t > 0) { msg_t--; hud_text(0, 16, msg_buf); }
  /* hotbar */
  for (int x = 5; x < 25; x++) for (int y = 17; y < 20; y++) hud_tile(x, y, T_PANEL);
  for (int i = 0; i < 9; i++) {
    int n = inv[i].id ? inv[i].n : 0;
    if (inv[i].id && inv[i].n > 1) {
      char b[4]; int k = itoa_(b, n);
      hud_text(6 + i * 2 + (k == 1 ? 1 : 0), 19, b);
    } else if (inv[i].id && inv[i].en) hud_text(7 + i * 2, 19, "*");
    if (inv[i].id != hb_cache[i]) { hb_cache[i] = inv[i].id; gfx_icon(S_ICON + i, inv[i].id); }
  }
  if (P.sel < 9) { /* cursor del hotbar */ }
}

void render_world(void) {
  cam_x = clampi(PX() - 120, 0, MW * 16 - 240);
  cam_y = clampi(PY() - 80, 0, MH * 16 - 160);
  int cx0 = cam_x >> 4, cy0 = cam_y >> 4;
  if (!win_valid || cx0 - wx0 > 1 || wx0 - cx0 > 1 || cy0 - wy0 > 1 || wy0 - cy0 > 1) {
    for (int y = cy0; y < cy0 + 16; y++) for (int x = cx0; x < cx0 + 16; x++) draw_cell(x, y);
    win_valid = 1; wx0 = cx0; wy0 = cy0; dark_t = -999;
  } else {
    while (wx0 < cx0) { for (int y = wy0; y < wy0 + 16; y++) draw_cell(wx0 + 16, y); wx0++; }
    while (wx0 > cx0) { wx0--; for (int y = wy0; y < wy0 + 16; y++) draw_cell(wx0, y); }
    while (wy0 < cy0) { for (int x = wx0; x < wx0 + 16; x++) draw_cell(x, wy0 + 16); wy0++; }
    while (wy0 > cy0) { wy0--; for (int x = wx0; x < wx0 + 16; x++) draw_cell(x, wy0); }
  }
  update_dark(cx0, cy0);
  scr_x = cam_x & 255; scr_y = cam_y & 255;
  /* sprites */
  oam_clear(); spr_n = 0;
  int bob = (P.moving && ((P.anim >> 3) & 1)) ? 1 : 0;
  int ppx = PX() - cam_x - 8, ppy = PY() - cam_y - 10;
  if (!(P.hurt > 0 && (P.hurt & 4)) && !P.sleeping) {
    int base = P.dir == 0 ? 0 : P.dir == 2 ? 2 : 4;
    spr(ppx, ppy, S_PLAYER + base + bob, 1, P.dir == 3, 0, 0);
  }
  if (P.sleeping) spr(ppx, ppy + 4, S_PLAYER + 4, 1, 0, 0, 0);
  if (P.swing > 0) spr(ppx + DX[P.dir] * 13, ppy + DY[P.dir] * 13 + 3, S_SPARK, 1, 0, 0, 0);
  if (P.fish_t != 0) spr(P.fish_x * 16 - cam_x, P.fish_y * 16 - cam_y, S_SPARK, 1, 0, 0, 2);
  for (int i = 0; i < MAXENT; i++) {
    Ent *e = &ents[i];
    if (!(e->flags & EF_ALIVE)) continue;
    const MobInfo *m = &MOBS[e->type];
    int sx = (e->x >> 4) - cam_x, sy = (e->y >> 4) - cam_y;
    if (e->hurt > 0 && (e->hurt & 2)) continue;
    int f = ((e->anim >> 3) & 1);
    if (e->flags & EF_FUSE) { if (e->t2 & 4) continue; }
    if (e->type == M_GHAST) spr(sx - 16, sy - 16, S_GHAST, 2, 0, 0, 2);
    else if (e->type == M_DRAGON) spr(sx - 16, sy - 16, S_DRAGON + f * 4, 2, e->dir == 3, 0, 2);
    else spr(sx - 8, sy - 10, S_MOB + (e->type - 1) * 2 + (m->ai == AI_SQUID || m->ai == AI_ANIMAL ? f : (e->st ? f : 0)), 1, e->dir == 3, 0, 2);
  }
  for (int i = 0; i < MAXPROJ; i++) {
    Proj *p = &projs[i];
    if (!p->type) continue;
    int sx = (p->x >> 4) - cam_x - 8, sy = (p->y >> 4) - cam_y - 8;
    if (p->type == 2) spr(sx, sy, S_FIRE, 1, 0, 0, 2);
    else spr(sx, sy, p->dir & 1 ? S_ARROWH : S_ARROW, 1, p->dir == 3, p->dir == 0, 2);
  }
  for (int i = 0; i < 6; i++)
    if (booms[i].t > 0) {
      int sx = (booms[i].x >> 4) - cam_x - 8, sy = (booms[i].y >> 4) - cam_y - 8, t = booms[i].t;
      spr(sx - t, sy, S_FIRE, 1, 0, 0, 0); spr(sx + t, sy, S_FIRE, 1, 0, 0, 0); spr(sx, sy - t, S_FIRE, 1, 0, 0, 0); spr(sx, sy + t, S_FIRE, 1, 0, 0, 0); spr(sx, sy, S_SPARK, 1, 0, 0, 0);
    }
  /* hotbar: iconos y seleccion */
  hud_clear();
  ui_draw_hud();
  for (int i = 0; i < 9; i++) if (inv[i].id) spr(40 + i * 16 + 0, 137, S_ICON + i, 1, 0, 0, 0);
  spr(40 + P.sel * 16, 137, S_RING, 1, 0, 0, 0);
}

/* ------------------------------------------------------------------- menus */
static void scroll_fix(int *cur, int *top, int count, int rows) {
  if (*cur < 0) *cur = count - 1;
  if (*cur >= count) *cur = 0;
  if (*cur < *top) *top = *cur;
  if (*cur >= *top + rows) *top = *cur - rows + 1;
  if (*top < 0) *top = 0;
}
static void fmt_slot(char *b, const Slot *s, int w) {
  char t[34];
  int k = 0;
  const char *nm = s->id ? item_name(s->id) : "-";
  while (nm[k] && k < w - 4) { t[k] = nm[k]; k++; }
  if (s->id && s->en) { t[k++] = '*'; }
  t[k] = 0;
  padtext(b, t, w);
  if (s->id && s->n > 1) { char n[8]; int l = itoa_(n, s->n); for (int i = 0; i < l; i++) b[w - l + i] = n[i]; }
}

static const char *PAUSE_ITEMS[] = {"Continuar", "Inventario", "Fabricar", "Mapa", "Logros", "Ayuda", "Guardar ranura 1", "Guardar ranura 2", "Objetos (creativo)", "Salir al titulo"};
#define PAUSE_N 10
static u8 cre_list[I_COUNT];
static int cre_n;

void ui_open(int kind, int arg) {
  menu_kind = kind; mcur = 0; mtop = 0; mpane = 0; marg = arg; mcat = 0; mredraw = 1; cur2 = top2 = 0; msel2 = -1;
  if (kind == MN_CRAFT) mcat = arg == 11 ? 11 : 0;
  if (kind == MN_CREATIVE) { cre_n = 0; for (int i = 1; i < I_COUNT; i++) if (ITM[i].name) cre_list[cre_n++] = (u8)i; }
  oam_clear(); oam_flush();
}
void ui_trade_open(Ent *e) { trade_ent = e; ui_open(MN_TRADE, e->aux % 5); }

static void close_menu(void) { menu_kind = MN_NONE; render_full_redraw(); for (int i = 0; i < 9; i++) hb_cache[i] = 255; hud_clear(); }
static void back_to_pause(void) { ui_open(MN_PAUSE, 0); }

static void draw_title_bar(const char *t) {
  hud_fill_panel();
  hud_text(1, 0, t);
  for (int x = 0; x < 30; x++) hud_tile(x, 1, T_BORDER);
  for (int x = 0; x < 30; x++) hud_tile(x, 18, T_BORDER);
}

static int cat_count(int cat) { int n = 0; for (int i = 0; i < RECIPE_N; i++) if (RECIPES[i].cat == cat) n++; return n; }
static const Recipe *cat_recipe(int cat, int k) { for (int i = 0; i < RECIPE_N; i++) if (RECIPES[i].cat == cat) { if (!k--) return &RECIPES[i]; } return 0; }

static void draw_recipe_need(const Recipe *r) {
  char b[34]; int k = 0;
  const u8 ids[4] = {r->i1, r->i2, r->i3, r->i4}, ns[4] = {r->n1, r->n2, r->n3, r->n4};
  hud_text(1, 17, "                             ");
  hud_text(1, 19, "                             ");
  int row = 17;
  for (int i = 0; i < 4; i++) {
    if (!ids[i]) continue;
    char t[34]; int l = 0;
    t[l++] = (char)('0' + ns[i] / 10 % 10 ? '0' + ns[i] / 10 % 10 : ' ');
    t[l++] = (char)('0' + ns[i] % 10);
    t[l++] = ' ';
    const char *nm = item_name(ids[i]);
    for (int q = 0; nm[q] && q < 12; q++) t[l++] = nm[q];
    t[l] = 0;
    hud_text(1 + (i & 1) * 14, row + (i >> 1) * 1, t);
    (void)b; (void)k;
  }
}

static void draw_menu(void) {
  char buf[40];
  switch (menu_kind) {
  case MN_PAUSE:
    draw_title_bar("PAUSA");
    for (int i = 0; i < PAUSE_N; i++) { hud_text(3, 3 + i, PAUSE_ITEMS[i]); }
    hud_text(1, 3 + mcur, ">");
    hud_text(1, 15, "A:elegir  B/Start:volver");
    hud_text(1, 16, "L/R: cambiar casilla");
    break;
  case MN_INV:
    draw_title_bar("INVENTARIO");
    for (int r = 0; r < 14; r++) {
      int i = mtop + r;
      if (i >= INV_N) break;
      fmt_slot(buf, &inv[i], 26);
      hud_text(3, 3 + r, buf);
      if (i < 9) { buf[0] = (char)('1' + i); buf[1] = 0; hud_text(0, 3 + r, buf); }
      if (i == msel2) hud_text(2, 3 + r, "*");
    }
    hud_text(1, 3 + mcur - mtop, ">");
    if (inv[mcur].id) {
      const ItemInfo *it = &ITM[inv[mcur].id];
      hud_text(1, 17, item_name(inv[mcur].id));
      if (inv[mcur].en) { hud_text(14, 17, ENCH_NAMES[EN_T(&inv[mcur])]); hud_text(25, 17, ROMAN[EN_L(&inv[mcur])]); }
      if (it->dur) { hud_text(1, 19, "Dur:"); hud_num(5, 19, inv[mcur].dur); }
    }
    hud_text(1, 18 + 0, "");
    hud_text(14, 19, "A:mover  B:salir");
    break;
  case MN_CRAFT: {
    int n = cat_count(mcat);
    draw_title_bar(marg == 11 ? "SOPORTE DE POCIONES" : "FABRICAR");
    if (marg != 11) { hud_text(1, 2, "<"); hud_text(3, 2, CAT_NAMES[mcat]); hud_text(28, 2, ">"); }
    for (int r = 0; r < 13; r++) {
      int i = mtop + r;
      if (i >= n) break;
      const Recipe *rc = cat_recipe(mcat, i);
      int ok = can_craft(rc) || P.mode == MODE_CREATIVE;
      hud_text(3, 3 + r, ok ? "+" : " ");
      hud_text(4, 3 + r, item_name(rc->out));
      if (rc->n > 1) { hud_text(24, 3 + r, "x"); hud_num(25, 3 + r, rc->n); }
    }
    hud_text(1, 3 + mcur - mtop, ">");
    if (n) draw_recipe_need(cat_recipe(mcat, mcur));
    break;
  }
  case MN_CHEST: {
    draw_title_bar("COFRE");
    hud_text(15, 0, "A:pasar  L/R:lado");
    int ci = marg;
    for (int r = 0; r < 15; r++) {
      int i = mtop + r;
      if (i < 27 && ci >= 0) { fmt_slot(buf, &chest_inv[ci][i], 13); hud_text(2, 3 + r, buf); }
      int j = top2 + r;
      if (j < INV_N) { fmt_slot(buf, &inv[j], 13); hud_text(16, 3 + r, buf); }
    }
    hud_text(mpane == 0 ? 1 : 15, 3 + (mpane == 0 ? mcur - mtop : cur2 - top2), ">");
    break;
  }
  case MN_TRADE: {
    draw_title_bar(PROF_NAMES[marg % 5]);
    for (int i = 0; i < TRADE_N[marg % 5]; i++) {
      const Trade *t = &TRADES[marg % 5][i];
      int k = 0; char b2[34];
      int ok = inv_count(t->give) >= t->gn;
      b2[k++] = ok ? '+' : ' ';
      k += itoa_(b2 + k, t->gn); b2[k++] = ' ';
      const char *nm = item_name(t->give); for (int q = 0; nm[q] && q < 10; q++) b2[k++] = nm[q];
      b2[k++] = ' '; b2[k++] = '>'; b2[k++] = ' ';
      k += itoa_(b2 + k, t->tn); b2[k++] = ' ';
      nm = item_name(t->get); for (int q = 0; nm[q] && q < 12; q++) b2[k++] = nm[q];
      b2[k] = 0;
      hud_text(3, 3 + i * 2, b2);
    }
    hud_text(1, 3 + mcur * 2, ">");
    hud_text(1, 17, "A: comerciar   B: salir");
    break;
  }
  case MN_ENCH: {
    draw_title_bar("MESA DE ENCANTAMIENTOS");
    Slot *s = &inv[P.sel];
    hud_text(1, 3, "Objeto en mano:");
    hud_text(1, 4, s->id ? item_name(s->id) : "(nada)");
    int kd = s->id ? ITM[s->id].kind : 99;
    int okk = (kd == K_SWORD || kd == K_PICK || kd == K_ARMOR || kd == K_BOW) && !s->en;
    if (!okk) hud_text(1, 6, s->en ? "Ya esta encantado" : "No se puede encantar");
    for (int i = 0; i < 3; i++) {
      hud_text(3, 8 + i * 2, "Nivel");
      hud_num(9, 8 + i * 2, i + 1);
      hud_text(12, 8 + i * 2, "cuesta");
      hud_num(19, 8 + i * 2, i + 1);
      hud_text(21, 8 + i * 2, "niv+");
      hud_num(25, 8 + i * 2, i + 1);
      hud_text(26, 8 + i * 2, "lap");
    }
    hud_text(1, 8 + mcur * 2, ">");
    hud_text(1, 16, "Tienes:");
    hud_num(9, 16, P.lvl); hud_text(12, 16, "niv"); hud_num(17, 16, inv_count(I_LAPIS)); hud_text(20, 16, "lapis");
    break;
  }
  case MN_ACH:
    draw_title_bar("LOGROS");
    for (int r = 0; r < 14; r++) {
      int i = mtop + r;
      if (i >= ACH_N) break;
      hud_text(2, 3 + r, (ach_mask & (1u << i)) ? "[x]" : "[ ]");
      hud_text(6, 3 + r, ACH_NAMES[i]);
    }
    hud_text(1, 17, "B: volver");
    break;
  case MN_CREATIVE:
    draw_title_bar("OBJETOS");
    for (int r = 0; r < 14; r++) {
      int i = mtop + r;
      if (i >= cre_n) break;
      hud_text(3, 3 + r, item_name(cre_list[i]));
    }
    hud_text(1, 3 + mcur - mtop, ">");
    hud_text(1, 17, "A: tomar pila   B: volver");
    break;
  case MN_HELP:
    draw_title_bar("AYUDA");
    hud_text(1, 3, "Cruz: mover / girar");
    hud_text(1, 5, "A: minar, atacar, usar");
    hud_text(1, 7, "B: poner bloque / usar objeto");
    hud_text(1, 9, "L / R: cambiar casilla");
    hud_text(1, 11, "Start: menu   Select: mapa");
    hud_text(1, 13, "Entra a las puertas de las");
    hud_text(1, 14, "colinas para ir a las cuevas.");
    hud_text(1, 15, "Anillo 3x3 de obsidiana=Nether");
    hud_text(1, 17, "B: volver");
    break;
  case MN_DEAD:
    hud_fill_panel();
    hud_text(8, 8, "HAS MUERTO");
    hud_text(5, 11, P.mode == MODE_HARD ? "Hardcore: mundo perdido" : "A: reaparecer");
    break;
  case MN_WIN:
    hud_fill_panel();
    hud_text(6, 6, "FELICIDADES!");
    hud_text(3, 9, "Has derrotado al Dragon");
    hud_text(3, 11, "del End. Puedes seguir");
    hud_text(3, 12, "jugando y construyendo.");
    hud_text(8, 15, "A: continuar");
    break;
  default: break;
  }
  mredraw = 0;
}

static void draw_map(void) {
  hud_fill_panel();
  int sc = cur_dim == D_OVER ? 4 : 2;
  int ox = clampi(PTX() - 15 * sc, 0, MW - 30 * sc), oy = clampi(PTY() - 10 * sc, 0, MH - 20 * sc);
  if (ox < 0) ox = 0;
  if (oy < 0) oy = 0;
  static const u8 col[G_COUNT] = {2, 8, 7, 9, 11, 5, 6, 12, 7, 3, 10, 6, 1, 8, 9, 7, 7, 7, 3, 3, 11};
  for (int cy = 0; cy < 20; cy++)
    for (int cx = 0; cx < 30; cx++) {
      int tx = ox + cx * sc + sc / 2, ty = oy + cy * sc + sc / 2;
      if (tx >= MW || ty >= MH) { hud_tile(cx, cy, 110 + 2 - 1); continue; }
      int c = col[getg(tx, ty)];
      u8 o = geto(tx, ty);
      if (o == O_MTN || o == O_STONE || o == O_COBB || o == O_CAVEW || o == O_ENDST) c = 10;
      else if (o == O_TREE || o == O_PINE || o == O_JTREE) c = 8;
      else if (o == O_DOOR || o == O_EXIT || o == O_NPORTAL || o == O_EPORTAL || o == O_WELL || o == O_FRAME) c = 1;
      else if (o == O_PLANK || o == O_CHEST) c = 7;
      hud_tile(cx, cy, 110 + c - 1);
    }
  int px = (PTX() - ox) / sc, py = (PTY() - oy) / sc;
  if ((game_time >> 4) & 1) hud_tile(px, py, T_CHAR('@'));
  hud_text(1, 19, "B: volver");
}

/* alterna slots */
static void slot_swap(int a, int b) {
  if (a == b) return;
  Slot t = inv[a];
  if (inv[a].id && inv[a].id == inv[b].id && !inv[a].en && !inv[b].en && inv[a].dur == 0 && inv[b].dur == 0) {
    int tot = inv[a].n + inv[b].n;
    inv[b].n = (u8)(tot > 64 ? 64 : tot); inv[a].n = (u8)(tot - inv[b].n);
    if (!inv[a].n) { inv[a].id = 0; inv[a].en = 0; }
    return;
  }
  inv[a] = inv[b]; inv[b] = t;
}

static void apply_enchant(int lvl) {
  Slot *s = &inv[P.sel];
  if (!s->id || s->en) return;
  int kd = ITM[s->id].kind, t1, t2;
  if (kd == K_SWORD) { t1 = E_SHARP; t2 = E_KNOCK; }
  else if (kd == K_PICK) { t1 = E_EFF; t2 = E_FORT; }
  else if (kd == K_ARMOR) { t1 = E_PROT; t2 = E_UNB; }
  else if (kd == K_BOW) { t1 = E_POWER; t2 = E_UNB; }
  else return;
  if (P.mode != MODE_CREATIVE) {
    if (P.lvl < lvl || inv_count(I_LAPIS) < lvl) { say("Faltan niveles o lapis"); return; }
    P.lvl -= lvl; P.xp = 0; inv_take(I_LAPIS, lvl);
  }
  int t = rnd(2) ? t1 : t2;
  s->en = (u8)((t << 2) | lvl);
  say("Encantado!");
}

int ui_update(u16 pressed, u16 held) {
  if (menu_kind == MN_NONE) return 0;
  int up = pressed & KEY_UP, dn = pressed & KEY_DOWN;
  /* autorepeticion */
  if (held & (KEY_UP | KEY_DOWN)) { mrep++; if (mrep > 14 && (mrep & 3) == 0) { if (held & KEY_UP) up = 1; else dn = 1; } } else mrep = 0;
  int A = pressed & KEY_A, B = pressed & KEY_B;
  int lf = pressed & (KEY_LEFT | KEY_L), rt = pressed & (KEY_RIGHT | KEY_R);
  int old = mcur, oldc = mcat, oldp = mpane;
  switch (menu_kind) {
  case MN_PAUSE:
    if (up) mcur--; if (dn) mcur++;
    if (mcur < 0) mcur = PAUSE_N - 1; if (mcur >= PAUSE_N) mcur = 0;
    if (pressed & KEY_L) { P.sel = (u8)((P.sel + 8) % 9); }
    if (pressed & KEY_R) { P.sel = (u8)((P.sel + 1) % 9); }
    if (B || (pressed & KEY_START)) { close_menu(); return 1; }
    if (A) {
      switch (mcur) {
      case 0: close_menu(); return 1;
      case 1: ui_open(MN_INV, 0); return 1;
      case 2: ui_open(MN_CRAFT, 0); return 1;
      case 3: ui_open(MN_MAP, 0); return 1;
      case 4: ui_open(MN_ACH, 0); return 1;
      case 5: ui_open(MN_HELP, 0); return 1;
      case 6: save_game(0); say("Partida guardada (1)"); close_menu(); return 1;
      case 7: save_game(1); say("Partida guardada (2)"); close_menu(); return 1;
      case 8: if (P.mode == MODE_CREATIVE) ui_open(MN_CREATIVE, 0); else mredraw = 1; return 1;
      case 9: menu_kind = MN_NONE; return 2; /* volver al titulo */
      }
    }
    break;
  case MN_INV:
    if (up) mcur--; if (dn) mcur++;
    scroll_fix(&mcur, &mtop, INV_N, 14);
    if (A) { if (msel2 < 0) { msel2 = mcur; } else { slot_swap(msel2, mcur); msel2 = -1; } mredraw = 1; }
    if (B) { if (msel2 >= 0) { msel2 = -1; mredraw = 1; } else back_to_pause(); return 1; }
    break;
  case MN_CRAFT: {
    int n = cat_count(mcat);
    if (marg != 11) { if (lf) mcat = (mcat + 11) % 11; if (rt) mcat = (mcat + 1) % 11; }
    if (mcat != oldc) { mcur = 0; mtop = 0; mredraw = 1; }
    if (up) mcur--; if (dn) mcur++;
    if (n) scroll_fix(&mcur, &mtop, n, 13);
    if (A && n) { do_craft(cat_recipe(mcat, mcur)); mredraw = 1; }
    if (B) { if (marg == 11) close_menu(); else back_to_pause(); return 1; }
    break;
  }
  case MN_CHEST: {
    int ci = marg;
    if (lf || rt) { mpane ^= 1; }
    if (mpane == 0) { if (up) mcur--; if (dn) mcur++; scroll_fix(&mcur, &mtop, 27, 15); }
    else { if (up) cur2--; if (dn) cur2++; scroll_fix(&cur2, &top2, INV_N, 15); }
    if (A && ci >= 0) {
      if (mpane == 0) {
        Slot *c = &chest_inv[ci][mcur];
        if (c->id) { int id = c->id, n = c->n; int left = inv_add((u8)id, n); c->n = (u8)left; if (!left) { c->id = 0; c->en = 0; } }
      } else {
        Slot *s = &inv[cur2];
        if (s->id) {
          for (int k = 0; k < 27; k++) {
            Slot *c = &chest_inv[ci][k];
            if (c->id == s->id && !s->en && !c->en && c->n + s->n <= 64 && !s->dur) { c->n = (u8)(c->n + s->n); s->id = 0; s->n = 0; break; }
          }
          if (s->id) for (int k = 0; k < 27; k++) if (!chest_inv[ci][k].id) { chest_inv[ci][k] = *s; s->id = 0; s->n = 0; s->en = 0; break; }
        }
      }
      mredraw = 1;
    }
    if (B) { close_menu(); return 1; }
    if (mpane != oldp) mredraw = 1;
    break;
  }
  case MN_TRADE: {
    int n = TRADE_N[marg % 5];
    if (up) mcur--; if (dn) mcur++;
    if (mcur < 0) mcur = n - 1; if (mcur >= n) mcur = 0;
    if (A) {
      const Trade *t = &TRADES[marg % 5][mcur];
      if (inv_count(t->give) >= t->gn && inv_can_add(t->get, t->tn)) {
        inv_take(t->give, t->gn); inv_add(t->get, t->tn); stat_trades++; add_xp(1); say("Trato hecho");
      } else say("No puedes comerciar");
      mredraw = 1;
    }
    if (B) { close_menu(); return 1; }
    break;
  }
  case MN_ENCH:
    if (up) mcur--; if (dn) mcur++;
    if (mcur < 0) mcur = 2; if (mcur > 2) mcur = 0;
    if (A) { apply_enchant(mcur + 1); mredraw = 1; }
    if (B) { close_menu(); return 1; }
    break;
  case MN_ACH:
    if (up) mcur--; if (dn) mcur++;
    scroll_fix(&mcur, &mtop, ACH_N, 14);
    mtop = mcur < 14 ? 0 : mcur - 13;
    if (B) { back_to_pause(); return 1; }
    break;
  case MN_CREATIVE:
    if (up) mcur--; if (dn) mcur++;
    scroll_fix(&mcur, &mtop, cre_n, 14);
    if (A) { u8 id = cre_list[mcur]; int st = ITM[id].kind == K_MAT || ITM[id].kind == K_PLACE || ITM[id].kind == K_FOOD ? 64 : 1; inv_add(id, st); say(item_name(id)); }
    if (B) { back_to_pause(); return 1; }
    break;
  case MN_MAP:
    draw_map();
    if (B || (pressed & (KEY_SELECT | KEY_START))) { close_menu(); return 1; }
    return 1;
  case MN_HELP:
    if (B) { back_to_pause(); return 1; }
    break;
  case MN_DEAD:
    if (A) {
      if (P.mode == MODE_HARD) { save_erase(cur_slot); menu_kind = MN_NONE; return 2; }
      respawn(); close_menu(); return 1;
    }
    break;
  case MN_WIN:
    if (A || B) { close_menu(); return 1; }
    break;
  default: close_menu(); return 1;
  }
  if (mcur != old) mredraw = 1;
  if (mredraw) { hud_fill_panel(); draw_menu(); }
  return 1;
}

int render_scroll_x(void) { return scr_x; }
int render_scroll_y(void) { return scr_y; }
