/* test.c - pruebas de humo de las mecanicas (se ejecuta en PC con el mismo codigo del juego) */
#define main host_main
#include "host.c"
#undef main
static int fails;
#define CHECK(c, msg) do { if (!(c)) { printf("FALLA: %s\n", msg); fails++; } else printf("ok: %s\n", msg); } while (0)
int main(void) {
  game_init(); step(5, 0); step(1, KEY_A); step(3, 0);
  /* minar un arbol */
  int tx = -1, ty = -1;
  for (int r = 2; r < 30 && tx < 0; r++) for (int dx = -r; dx <= r && tx < 0; dx++) { int x = PTX() + dx, y = PTY(); if (geto(x, y) == O_TREE && tile_walk(x - 1, y)) { tx = x; ty = y; } }
  if (tx < 0) { tx = PTX() + 2; ty = PTY(); seto(tx, ty, O_TREE); }
  tp(tx - 1, ty); P.dir = 3; P.sel = 0; inv[0].id = 0;
  int w0 = inv_count(I_WOOD);
  step(120, KEY_A);
  CHECK(inv_count(I_WOOD) > w0 && geto(tx, ty) == 0, "minar arbol da madera");
  /* craftear */
  const Recipe *r = &RECIPES[0];
  CHECK(r->out == I_PLANK, "receta 0 = tablon");
  inv_add(I_WOOD, 2); int p0 = inv_count(I_PLANK); do_craft(r);
  CHECK(inv_count(I_PLANK) == p0 + 4, "craftear tablon");
  /* colocar y portal del Nether */
  tp(60, 60); P.dir = 3;
  int cx = 63, cy = 60;
  for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) { seto(cx + dx, cy + dy, 0); setg(cx + dx, cy + dy, G_GRASS); }
  inv_add(I_OBSIDIAN, 8);
  for (int i = 0; i < INV_N; i++) if (inv[i].id == I_OBSIDIAN) P.sel = (i < 9) ? (u8)i : 0;
  if (inv[P.sel].id != I_OBSIDIAN) { inv[8] = inv[P.sel]; inv[P.sel].id = I_OBSIDIAN; inv[P.sel].n = 8; }
  int placed = 0;
  for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) if (dx || dy) { seto(cx + dx, cy + dy, O_OBS); placed++; }
  tp(cx - 3, cy); P.dir = 3; seto(cx - 2, cy, 0);
  /* el ultimo bloque se coloca con B */
  seto(cx - 1, cy, 0); tp(cx - 3, cy); P.dir = 3; P.sel = P.sel; P.cd = 0;
  P.x = (cx - 2) * 256 + 128; P.y = cy * 256 + 128; P.dir = 3; P.cd = 0;
  step(1, 0); host_keys = 0;
  use_item_b();
  CHECK(geto(cx - 1, cy) == O_OBS, "colocar obsidiana con B");
  CHECK(geto(cx, cy) == O_NPORTAL, "anillo de obsidiana crea portal");
  P.x = cx * 256 + 128; P.y = cy * 256 + 128;
  step(90, 0);
  CHECK(cur_dim == D_NETH, "portal lleva al Nether");
  /* volver */
  P.x = 8 * 256 + 128; P.y = 52 * 256 + 128; step(90, 0);
  CHECK(cur_dim == D_OVER, "portal de regreso");
  /* cuevas */
  P.x = door_pt[0].x * 256 + 128; P.y = door_pt[0].y * 256 + 128; step(3, 0);
  CHECK(cur_dim == D_CAVE, "puerta lleva a las cuevas");
  change_dim(D_OVER, 60, 60);
  /* redstone: palanca + piston */
  for (int y = 55; y < 66; y++) for (int x = 55; x < 66; x++) { seto(x, y, 0); setg(x, y, G_GRASS); }
  seto(58, 60, O_LEVER); seto(59, 60, O_WIRE); seto(60, 60, O_PISTON); wst[tidx(60, 60)] = 3; seto(61, 60, O_COBB);
  rs_neighbor_changed(58, 60); rs_neighbor_changed(60, 60);
  step(20, 0);
  CHECK(geto(61, 60) == O_COBB, "piston sin energia no empuja");
  wst[tidx(58, 60)] |= 0x80; step(30, 0);
  CHECK(geto(61, 60) == O_PHEAD && geto(62, 60) == O_COBB, "palanca+cable activa piston y empuja bloque");
  wst[tidx(58, 60)] &= 0x7F; step(30, 0);
  CHECK(geto(61, 60) == 0, "al apagar, el piston se retrae");
  /* cultivos */
  setg(56, 56, G_SOILW); seto(56, 56, O_WHEAT0);
  for (int i = 0; i < 20000 && geto(56, 56) != O_WHEAT3; i++) { ents_clear(); sim_world(); }
  CHECK(geto(56, 56) == O_WHEAT3, "el trigo crece hasta madurar");
  /* comercio */
  inv_add(I_WHEAT, 10); int e0 = inv_count(I_EMERALD);
  ui_open(MN_TRADE, 0); step(1, 0); step(1, KEY_A); step(1, 0);
  CHECK(inv_count(I_EMERALD) == e0 + 1, "comerciar trigo por esmeralda");
  menu_kind = MN_NONE;
  /* guardar / cargar */
  seto(57, 57, O_CHEST); int ci = chest_find(57, 57, 1); chest_inv[ci][0].id = I_DIAMOND; chest_inv[ci][0].n = 5;
  inv_add(I_GOLD, 7); P.lvl = 9; seto(70, 70, O_GOLDB);
  save_game(1);
  P.lvl = 0; inv_take(I_GOLD, 7); seto(70, 70, 0);
  CHECK(load_game(1), "cargar partida");
  CHECK(P.lvl == 9 && inv_count(I_GOLD) >= 7 && geto(70, 70) == O_GOLDB, "guardado conserva inventario y bloques modificados");
  ci = chest_find(57, 57, 0);
  CHECK(ci >= 0 && chest_inv[ci][0].id == I_DIAMOND, "guardado conserva el cofre");
  /* dragon */
  change_dim(D_END, 24, 38);
  Ent *d = 0; for (int i = 0; i < MAXENT; i++) if (ents[i].type == M_DRAGON && (ents[i].flags & EF_ALIVE)) d = &ents[i];
  CHECK(d != 0, "el dragon aparece en el End");
  if (d) { ent_damage(d, 100, 0, 0); }
  CHECK(P.won && geto(24, 24) == O_XPORTAL, "vencer al dragon abre el portal de salida");
  /* encantar */
  P.lvl = 5; P.sel = 8; inv[8].id = I_ISWORD; inv[8].n = 1; inv[8].en = 0; inv[8].dur = 100; inv_add(I_LAPIS, 3);
  ui_open(MN_ENCH, 0); step(1, 0); step(1, KEY_A); step(1, 0); menu_kind = MN_NONE;
  CHECK(inv[8].en != 0, "mesa de encantamientos encanta la espada");
  printf("%s (%d fallos)\n", fails ? "HAY FALLOS" : "TODO OK", fails);
  return fails != 0;
}
