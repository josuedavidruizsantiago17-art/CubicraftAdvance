/* fuzz.c - entrada aleatoria prolongada para detectar fallos de memoria (con ASan/UBSan en PC) */
#define main host_main
#include "host.c"
#undef main
int main(void) {
  game_init(); step(3, 0); step(1, KEY_A); step(3, 0);
  P.mode = MODE_CREATIVE;
  for (int i = 1; i < I_COUNT; i++) if (ITM[i].name) inv_add((u8)i, 20);
  u32 s = 12345;
  for (int f = 0; f < 60000; f++) {
    s = s * 1664525u + 1013904223u;
    u16 k = 0;
    int r = (s >> 16) & 255;
    if (r < 90) k |= (u16)(1 << (4 + ((s >> 8) & 3)));
    if (r % 7 == 0) k |= KEY_A;
    if (r % 11 == 0) k |= KEY_B;
    if (r == 250) k |= KEY_START;
    if (r == 249) k |= KEY_SELECT;
    if (r == 248) k |= (s & 0x100) ? KEY_L : KEY_R;
    host_keys = k; game_frame();
    if (f % 4000 == 0) { int d = (f / 4000) % 4; change_dim(d, spawn_pt[d].x, spawn_pt[d].y); }
    if (P.dead) { P.dead = 0; P.hp = 20; menu_kind = MN_NONE; }
    if (f % 9000 == 8999) save_game(0), load_game(0);
  }
  printf("fuzz ok t=%u\n", game_time);
  return 0;
}
