#!/bin/sh
# Genera capturas de pantalla en PC (necesita gcc y python3 con Pillow). No hace falta para compilar la ROM.
set -e
cd "$(dirname "$0")/.."
mkdir -p preview/out
gcc -DHOST -O1 -w -o preview/out/host preview/host.c source/data.c source/art.c source/gfx.c source/world.c source/player.c source/entity.c source/redstone.c source/ui.c source/save.c source/main.c
./preview/out/host preview/out
python3 - <<'P'
from PIL import Image
import glob
for f in sorted(glob.glob('preview/out/*.ppm')):
    Image.open(f).resize((720, 480), Image.NEAREST).save(f.replace('.ppm', '.png'))
P
echo "Capturas en preview/out/"
