/* redstone.c - simulacion simplificada de redstone (tick cada 0,1 s):
   cables con atenuacion 15->1, antorchas inversoras, repetidores con retardo, comparadores,
   observadores, pistones (normal y pegajoso), lamparas, dispensadores, tolvas, TNT, aspersores y cosechadoras. */
#include "game.h"

#define RSMAX 320
static u8 rl_x[RSMAX], rl_y[RSMAX];
static u16 rl_sig[RSMAX];
static int rl_n;
int rs_dirty;

static int is_rs(u8 o) {
  switch (o) {
  case O_RBLOCK: case O_RTORCH: case O_LEVER: case O_BUTTON: case O_PLATE: case O_OBSERVER: case O_WIRE:
  case O_REPEATER: case O_COMPARATOR: case O_PISTON: case O_STICKY: case O_LAMP: case O_DISPENSER:
  case O_HOPPER: case O_SPRINK: case O_HARV: case O_TNT: return 1;
  default: return 0;
  }
}
static u16 sig_of(int x, int y) {
  if (!tinb(x, y)) return 0;
  return (u16)(geto(x, y) | (getg(x, y) << 8) | ((wst[tidx(x, y)] & 0x83) << 5));
}
static void reg(int x, int y) {
  for (int i = 0; i < rl_n; i++) if (rl_x[i] == x && rl_y[i] == y) return;
  if (rl_n >= RSMAX) return;
  rl_x[rl_n] = (u8)x; rl_y[rl_n] = (u8)y;
  int d = wst[tidx(x, y)] & 3;
  rl_sig[rl_n] = sig_of(x + DX[d], y + DY[d]);
  rl_n++;
}
void rs_neighbor_changed(int x, int y) {
  rs_dirty = 1;
  if (x < 0) {
    rl_n = 0;
    for (int yy = 0; yy < MH; yy++) for (int xx = 0; xx < MW; xx++) if (is_rs(wo[tidx(xx, yy)])) reg(xx, yy);
    return;
  }
  for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) if (is_rs(geto(x + dx, y + dy))) reg(x + dx, y + dy);
}
int rs_sprinkler_near(int x, int y) {
  for (int i = 0; i < rl_n; i++) {
    int dx = rl_x[i] - x, dy = rl_y[i] - y;
    if (dx >= -3 && dx <= 3 && dy >= -3 && dy <= 3 && geto(rl_x[i], rl_y[i]) == O_SPRINK && wrs[tidx(rl_x[i], rl_y[i])]) return 1;
  }
  return 0;
}

/* potencia que el bloque (x,y) entrega a la casilla vecina (tx,ty) */
static int emit(int x, int y, int tx, int ty) {
  u8 o = geto(x, y);
  int i = tidx(x, y);
  u8 st = wst[i];
  int d = st & 3;
  switch (o) {
  case O_RBLOCK: return 15;
  case O_LEVER: case O_BUTTON: case O_PLATE: return (st & 0x80) ? 15 : 0;
  case O_RTORCH: return ((st & 0x80) && !(tx == x + DX[d] && ty == y + DY[d])) ? 15 : 0;
  case O_REPEATER: return ((st & 0x80) && tx == x + DX[d] && ty == y + DY[d]) ? 15 : 0;
  case O_COMPARATOR: return ((st & 0x80) && tx == x + DX[d] && ty == y + DY[d]) ? wrs[i] : 0;
  case O_OBSERVER: return ((st & 0x80) && tx == x - DX[d] && ty == y - DY[d]) ? 15 : 0;
  case O_WIRE: return wrs[i];
  default: return 0;
  }
}
static int power_in(int x, int y, int skx, int sky) {
  int m = 0;
  for (int d = 0; d < 4; d++) {
    int nx = x + DX[d], ny = y + DY[d];
    if (nx == skx && ny == sky) continue;
    int e = emit(nx, ny, x, y);
    if (e > m) m = e;
  }
  return m;
}
static void setst(int x, int y, u8 v) {
  int i = tidx(x, y);
  if (wst[i] != v) { wst[i] = v; render_tile(x, y); wdirty[i >> 3] |= (u8)(1 << (i & 7)); }
}
static int is_container(u8 o) { return o == O_CHEST || o == O_DISPENSER || o == O_HOPPER; }

/* ---------------------------------------------------------------- pistones */
static int push_chain(int x, int y, int d) {
  int n = 0, cx = x, cy = y;
  while (geto(cx, cy)) {
    u8 o = geto(cx, cy);
    if ((BLK[o].flags & BF_UNB) || o == O_PHEAD) return 0;
    if (++n > 12) return 0;
    cx += DX[d]; cy += DY[d];
  }
  if (!tinb(cx, cy) || getg(cx, cy) == G_VOID) return 0;
  for (int k = n; k > 0; k--) {
    int sx = x + DX[d] * (k - 1), sy = y + DY[d] * (k - 1), tx = sx + DX[d], ty = sy + DY[d];
    seto(tx, ty, geto(sx, sy));
    wst[tidx(tx, ty)] = wst[tidx(sx, sy)];
    wrs[tidx(tx, ty)] = wrs[tidx(sx, sy)];
    seto(sx, sy, 0);
    rs_neighbor_changed(tx, ty);
  }
  return 1;
}
static void piston_ext(int x, int y, int d) {
  int fx = x + DX[d], fy = y + DY[d];
  if (push_chain(fx, fy, d)) {
    seto(fx, fy, O_PHEAD);
    wst[tidx(fx, fy)] = (u8)d;
    setst(x, y, (u8)(wst[tidx(x, y)] | 0x80));
  }
}
static void piston_ret(int x, int y, int d, int sticky) {
  int fx = x + DX[d], fy = y + DY[d];
  if (geto(fx, fy) == O_PHEAD) seto(fx, fy, 0);
  if (sticky) {
    int bx = fx + DX[d], by = fy + DY[d];
    u8 o = geto(bx, by);
    if (o && !(BLK[o].flags & BF_UNB) && o != O_PHEAD) {
      seto(fx, fy, o); wst[tidx(fx, fy)] = wst[tidx(bx, by)]; wrs[tidx(fx, fy)] = wrs[tidx(bx, by)];
      seto(bx, by, 0); rs_neighbor_changed(fx, fy);
    }
  }
  setst(x, y, (u8)(wst[tidx(x, y)] & ~0x80));
}

/* -------------------------------------------------------- contenedores */
static int container_take(int x, int y, u8 *id) {
  int ci = chest_find(x, y, 0);
  if (ci < 0) return 0;
  for (int k = 0; k < 27; k++) if (chest_inv[ci][k].id) { *id = chest_inv[ci][k].id; if (!--chest_inv[ci][k].n) chest_inv[ci][k].id = 0; return 1; }
  return 0;
}
static int container_put(int x, int y, u8 id) {
  int ci = chest_find(x, y, 1);
  if (ci < 0) return 0;
  for (int k = 0; k < 27; k++) if (chest_inv[ci][k].id == id && chest_inv[ci][k].n < 64) { chest_inv[ci][k].n++; return 1; }
  for (int k = 0; k < 27; k++) if (!chest_inv[ci][k].id) { chest_inv[ci][k].id = id; chest_inv[ci][k].n = 1; chest_inv[ci][k].dur = ITM[id].dur; return 1; }
  return 0;
}
static void dispense(int x, int y, int d) {
  int ci = chest_find(x, y, 0);
  if (ci < 0) return;
  int fx = x + DX[d], fy = y + DY[d];
  for (int k = 0; k < 27; k++) {
    Slot *s = &chest_inv[ci][k];
    if (!s->id) continue;
    const ItemInfo *it = &ITM[s->id];
    int used = 0;
    if (s->id == I_ARROW) { proj_spawn(1, fx * 256 + 128 - DX[d] * 96, fy * 256 + 128 - DY[d] * 96, DX[d] * 56, DY[d] * 56, 4, 1); used = 1; }
    else if (s->id == I_WBUCKET && !geto(fx, fy) && getg(fx, fy) != G_VOID) { setg(fx, fy, G_WATER); s->id = I_BUCKET; continue; }
    else if (s->id == I_LBUCKET && !geto(fx, fy) && getg(fx, fy) != G_VOID) { setg(fx, fy, G_LAVA); s->id = I_BUCKET; continue; }
    else if (it->kind == K_PLACE && !geto(fx, fy) && tinb(fx, fy) && !is_water(fx, fy) && getg(fx, fy) != G_VOID) { seto(fx, fy, it->a); wst[tidx(fx, fy)] = (u8)d; rs_neighbor_changed(fx, fy); used = 1; }
    else if (s->id == I_TNTB) { used = 0; }
    if (used) { if (!--s->n) s->id = 0; }
    return;
  }
}
static void harvest(int x, int y) {
  for (int dy = -3; dy <= 3; dy++)
    for (int dx = -3; dx <= 3; dx++) {
      int cx = x + dx, cy = y + dy;
      u8 o = geto(cx, cy);
      int w = o == O_WHEAT3, c = o == O_CARROT3;
      if (!w && !c) continue;
      u8 id = w ? I_WHEAT : I_CARROT;
      int n = w ? 2 : 3, placed = 0;
      for (int d = 0; d < 4 && !placed; d++) if (is_container(geto(x + DX[d], y + DY[d]))) placed = container_put(x + DX[d], y + DY[d], id);
      if (!placed) inv_add(id, n);
      seto(cx, cy, w ? O_WHEAT0 : O_CARROT0);
    }
}

/* --------------------------------------------------------------------- tick */
void rs_tick(void) {
  if (!rl_n) return;
  int px = PTX(), py = PTY();
  /* limpieza y temporizadores */
  for (int k = 0; k < rl_n; k++) {
    int x = rl_x[k], y = rl_y[k];
    u8 o = geto(x, y);
    if (!is_rs(o)) { rl_n--; rl_x[k] = rl_x[rl_n]; rl_y[k] = rl_y[rl_n]; rl_sig[k] = rl_sig[rl_n]; k--; continue; }
    int i = tidx(x, y);
    if (o == O_BUTTON && (wst[i] & 0x80)) { if (wrs[i] > 0) wrs[i]--; if (!wrs[i]) setst(x, y, (u8)(wst[i] & ~0x80)); }
    if (o == O_PLATE) {
      int on = (px == x && py == y);
      for (int e = 0; e < MAXENT && !on; e++) if ((ents[e].flags & EF_ALIVE) && (ents[e].x >> 8) == x && (ents[e].y >> 8) == y) on = 1;
      if (on != ((wst[i] & 0x80) != 0)) setst(x, y, on ? 0x80 : 0);
    }
  }
  /* cables */
  for (int k = 0; k < rl_n; k++) {
    int x = rl_x[k], y = rl_y[k];
    if (geto(x, y) != O_WIRE) continue;
    int m = 0;
    for (int d = 0; d < 4; d++) {
      int nx = x + DX[d], ny = y + DY[d];
      if (geto(nx, ny) == O_WIRE) continue;
      int e = emit(nx, ny, x, y);
      if (e > m) m = e;
    }
    wrs[tidx(x, y)] = (u8)m;
  }
  for (int L = 15; L >= 2; L--)
    for (int k = 0; k < rl_n; k++) {
      int x = rl_x[k], y = rl_y[k];
      if (geto(x, y) != O_WIRE || wrs[tidx(x, y)] != L) continue;
      for (int d = 0; d < 4; d++) {
        int nx = x + DX[d], ny = y + DY[d];
        if (geto(nx, ny) == O_WIRE && wrs[tidx(nx, ny)] < L - 1) wrs[tidx(nx, ny)] = (u8)(L - 1);
      }
    }
  for (int k = 0; k < rl_n; k++) {
    int x = rl_x[k], y = rl_y[k];
    if (geto(x, y) != O_WIRE) continue;
    int i = tidx(x, y);
    u8 want = wrs[i] ? 0x80 : 0;
    if ((wst[i] & 0x80) != want) setst(x, y, want);
  }
  /* dispositivos */
  for (int k = 0; k < rl_n; k++) {
    int x = rl_x[k], y = rl_y[k];
    u8 o = geto(x, y);
    int i = tidx(x, y);
    u8 st = wst[i];
    int d = st & 3;
    switch (o) {
    case O_LAMP: { int on = power_in(x, y, -1, -1) > 0; if (on != ((st & 0x80) != 0)) setst(x, y, on ? 0x80 : 0); break; }
    case O_RTORCH: {
      int fx = x + DX[d], fy = y + DY[d];
      int powered = power_in(fx, fy, x, y) > 0;
      if (geto(fx, fy) == O_WIRE && wrs[tidx(fx, fy)]) powered = 1;
      u8 want = (u8)((st & 3) | (powered ? 0 : 0x80));
      if (want != st) setst(x, y, want);
      break;
    }
    case O_REPEATER: {
      int in = emit(x - DX[d], y - DY[d], x, y) > 0;
      int delay = ((st >> 2) & 3) + 1, out = (st & 0x80) != 0;
      if (in != out) { if (++wrs[i] >= delay) { wrs[i] = 0; setst(x, y, in ? (u8)(st | 0x80) : (u8)(st & ~0x80)); } }
      else wrs[i] = 0;
      break;
    }
    case O_COMPARATOR: {
      int bx = x - DX[d], by = y - DY[d], b;
      if (is_container(geto(bx, by))) {
        int ci = chest_find(bx, by, 0), f = 0;
        if (ci >= 0) for (int q = 0; q < 27; q++) if (chest_inv[ci][q].id) f++;
        b = f ? 1 + f * 14 / 27 : 0;
      } else b = emit(bx, by, x, y);
      int s1 = emit(x + DX[(d + 1) & 3], y + DY[(d + 1) & 3], x, y), s2 = emit(x + DX[(d + 3) & 3], y + DY[(d + 3) & 3], x, y);
      int sd = s1 > s2 ? s1 : s2, out;
      if (st & 4) out = b - sd > 0 ? b - sd : 0; else out = b >= sd ? b : 0;
      wrs[i] = (u8)out;
      u8 want = (u8)((st & ~0x80) | (out ? 0x80 : 0));
      if (want != st) setst(x, y, want);
      break;
    }
    case O_OBSERVER: {
      int fx = x + DX[d], fy = y + DY[d];
      u16 s = sig_of(fx, fy);
      if (st & 0x80) { if (wrs[i] > 0) wrs[i]--; if (!wrs[i]) setst(x, y, (u8)(st & ~0x80)); }
      else if (s != rl_sig[k]) { wrs[i] = 2; setst(x, y, (u8)(st | 0x80)); }
      rl_sig[k] = s;
      break;
    }
    case O_PISTON: case O_STICKY: {
      int on = power_in(x, y, x + DX[d], y + DY[d]) > 0;
      if (on && !(st & 0x80)) piston_ext(x, y, d);
      else if (!on && (st & 0x80)) piston_ret(x, y, d, o == O_STICKY);
      break;
    }
    case O_DISPENSER: {
      int on = power_in(x, y, -1, -1) > 0;
      if (on && !(st & 0x40)) { dispense(x, y, d); wst[i] |= 0x40; }
      else if (!on && (st & 0x40)) wst[i] &= (u8)~0x40;
      break;
    }
    case O_HOPPER: {
      if (power_in(x, y, -1, -1) > 0) break;
      if (++wrs[i] < 4) break;
      wrs[i] = 0;
      int bx = x - DX[d], by = y - DY[d], fx = x + DX[d], fy = y + DY[d];
      if (is_container(geto(bx, by)) && is_container(geto(fx, fy))) {
        u8 id;
        if (container_take(bx, by, &id)) { if (!container_put(fx, fy, id)) container_put(bx, by, id); }
      }
      break;
    }
    case O_SPRINK: wrs[i] = (u8)(power_in(x, y, -1, -1) > 0); break;
    case O_HARV: {
      int on = power_in(x, y, -1, -1) > 0;
      if (on && !(st & 0x40)) { harvest(x, y); wst[i] |= 0x40; }
      else if (!on && (st & 0x40)) wst[i] &= (u8)~0x40;
      break;
    }
    case O_TNT:
      if (power_in(x, y, -1, -1) > 0) { tnt_light(x, y); seto(x, y, 0); }
      break;
    default: break;
    }
  }
}

void rs_toggle(int x, int y) { (void)x; (void)y; }
void rs_press_plate(int x, int y) { (void)x; (void)y; }
