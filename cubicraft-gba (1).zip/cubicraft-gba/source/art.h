/* art.h - GENERADO por tools/gen_art.py (texturas originales de Cubicraft). No editar. */
#ifndef ART_H
#define ART_H
#include "data.h"
extern const u8 ART_BLOB[];
extern const u16 ART_PAL[241];
extern const u8 ART_PM[241];       /* indice de rampa antigua -> indice nuevo */
extern const u32 ART_G[G_COUNT], ART_W[3], ART_L[3];
extern const u32 ART_O[O_COUNT], ART_OA[O_COUNT], ART_I[I_COUNT];
extern const u32 ART_MOB[M_COUNT][3][2];  /* [mob][vista 0 abajo 1 arriba 2 lado][frame] */
extern const u8 ART_MOBH[M_COUNT];        /* 0 = procedural, 16 o 32 = alto del lienzo */
extern const u32 ART_PLAYER[3][2];        /* 16x32 */
#endif
