/* data.h - tipos, enums y tablas del juego (portados de Cubicraft RPG) */
#ifndef DATA_H
#define DATA_H
#include "gba.h"

/* ---------- suelos ---------- */
enum {
  G_VOID, G_GRASS, G_DIRT, G_SAND, G_WATER, G_LAVA, G_CAVE, G_NETH, G_NBF, G_END,
  G_SBF, G_PBASE, G_SNOW, G_JGRASS, G_PATH, G_WOOD, G_SOIL, G_SOILW, G_GRASSF1, G_GRASSF2,
  G_DEEP, G_COUNT
};

/* ---------- objetos / bloques (capa 2) ---------- */
enum {
  O_NONE, O_TREE, O_STONE, O_COAL, O_IRON, O_DIAM, O_OBS, O_PLANK, O_COBB, O_TORCH,
  O_NRACK, O_DOOR, O_EXIT, O_NPORTAL, O_FRAME, O_FRAMEF, O_EPORTAL, O_XPORTAL, O_BED, O_RBLOCK,
  O_RTORCH, O_LEVER, O_BUTTON, O_PLATE, O_OBSERVER, O_WIRE, O_REPEATER, O_COMPARATOR, O_PISTON, O_STICKY,
  O_PHEAD, O_LAMP, O_DISPENSER, O_HOPPER, O_CHEST, O_RORE, O_CACTUS, O_PINE, O_JTREE, O_WHEAT0,
  O_WHEAT1, O_WHEAT2, O_WHEAT3, O_CARROT0, O_CARROT1, O_CARROT2, O_CARROT3, O_SPRINK, O_HARV, O_LAPIS,
  O_QORE, O_NGOLD, O_DEBRIS, O_GLOWS, O_BASALT, O_CTREE, O_WTREE, O_WART, O_PURPUR, O_CHORUS,
  O_GATE, O_ENCH, O_BREW, O_CORALR, O_CORALY, O_CORALB, O_CORALP, O_KELP, O_SEAGR, O_PRISM,
  O_SPONGE, O_GOLDB, O_WRECK, O_COBWEB, O_DSPAWN, O_TNT, O_LANTERN, O_SOULF, O_MAGMA, O_MTN,
  O_CAVEW, O_NBW, O_SBW, O_BRICK, O_WELL, O_ENDST, O_COUNT
};

/* flags de bloque */
#define BF_WALK 1   /* se puede atravesar */
#define BF_UNB 2    /* irrompible */
#define BF_LIGHT 4  /* emite luz */
#define BF_ALT 8    /* tiene sprite alternativo (estado encendido) */
#define BF_DIR 16   /* orientable (usa flips) */
#define BF_INT 32   /* se interactua con A */
#define BF_TRANS 64 /* fondo transparente (se dibuja sobre el suelo) */

typedef struct {
  u8 hp, tier, flags, drop; /* drop = item que suelta (0 = nada) */
  u8 dn;                    /* cantidad base */
  u8 light;                 /* radio de luz en casillas */
  u8 xp;
} BlockInfo;
extern const BlockInfo BLK[O_COUNT];

/* ---------- objetos del inventario ---------- */
enum {
  I_NONE, I_WOOD, I_PLANK, I_STICK, I_COBBLE, I_COAL, I_IRON, I_DIAMOND, I_OBSIDIAN, I_TORCH,
  I_BUCKET, I_WBUCKET, I_LBUCKET, I_WPICK, I_SPICK, I_IPICK, I_DPICK, I_NPICK, I_WSWORD, I_SSWORD,
  I_ISWORD, I_DSWORD, I_NSWORD, I_APPLE, I_RAW, I_COOKED, I_ROD, I_PEARL, I_EYE, I_WOOL,
  I_BED, I_SHIELD, I_REDSTONE, I_RBLOCK, I_RTORCH, I_LEVER, I_BUTTON, I_PLATE, I_OBSERVER, I_REPEATER,
  I_COMPARATOR, I_PISTON, I_STICKY, I_LAMP, I_DISPENSER, I_HOPPER, I_CHEST, I_BOW, I_ARROW, I_FEATHER,
  I_SLIME, I_GOLD, I_IARMOR, I_GARMOR, I_DARMOR, I_NARMOR, I_LARMOR, I_VIAL, I_PHEAL, I_PSPEED,
  I_PSTR, I_PFIRE, I_PREGEN, I_PNIGHT, I_PRES, I_HOE, I_SEED, I_WHEAT, I_CARROT, I_BREAD,
  I_SPRINK, I_HARV, I_LAPIS, I_QUARTZ, I_SCRAP, I_NETHERITE, I_GLOWDUST, I_NWART, I_BONE, I_GUNPOWDER,
  I_STRING, I_LEATHER, I_ENCH, I_BREW, I_GLOWS, I_PURPUR, I_GOLDB, I_TNTB, I_CHORUS, I_KELP,
  I_DKELP, I_CORAL, I_COD, I_SALMON, I_CKFISH, I_CKSALMON, I_FROD, I_EMERALD, I_CSTEM, I_WSTEM,
  I_NSTAR, I_SPONGE, I_PRISMB, I_SHARD, I_CACTUS, I_BRICK, I_SOULSAND, I_PEARLB, I_COUNT
};

/* clases de objeto */
enum { K_MAT, K_PICK, K_SWORD, K_FOOD, K_PLACE, K_ARMOR, K_BOW, K_POTION, K_TOOL, K_SPECIAL };

typedef struct {
  const char *name;
  u8 kind;
  u8 a;    /* tier / dano / comida(medios corazones) / bloque a colocar */
  u8 b;    /* dano herramienta / armadura(%) / efecto pocion */
  u8 dur;  /* durabilidad (0 = no se gasta) */
  u8 ramp; /* color principal (paleta) */
} ItemInfo;
extern const ItemInfo ITM[I_COUNT];

/* ---------- recetas ---------- */
typedef struct {
  u8 cat, out, n, i1, n1, i2, n2, i3, n3, i4, n4;
} Recipe;
extern const Recipe RECIPES[];
extern const int RECIPE_N;
extern const char *const CAT_NAMES[];
#define CAT_N 12

/* ---------- mobs ---------- */
enum {
  M_NONE, M_COW, M_PIG, M_SHEEP, M_CHICKEN, M_ZOMBIE, M_ENDERMAN, M_BLAZE, M_PIGLIN, M_DRAGON,
  M_CREEPER, M_SKELETON, M_GHAST, M_VILLAGER, M_CAT, M_SQUID, M_COUNT
};
enum { AI_ANIMAL, AI_ZOMBIE, AI_ENDER, AI_BLAZE, AI_PIGLIN, AI_DRAGON, AI_CREEPER, AI_SKEL, AI_GHAST, AI_VILL, AI_CAT, AI_SQUID };
typedef struct {
  const char *name;
  u8 hp, speed, ai, fly;
  u8 dmg, xp;
  u8 w; /* tamano sprite en casillas (1 o 2) */
} MobInfo;
extern const MobInfo MOBS[M_COUNT];

/* ---------- encantamientos ---------- */
enum { E_NONE, E_SHARP, E_EFF, E_FORT, E_PROT, E_POWER, E_UNB, E_KNOCK, E_COUNT };
extern const char *const ENCH_NAMES[E_COUNT];

/* ---------- comercio ---------- */
typedef struct {
  u8 give, gn, get, tn;
} Trade;
extern const Trade TRADES[5][6];
extern const u8 TRADE_N[5];
extern const char *const PROF_NAMES[5];

/* ---------- logros ---------- */
#define ACH_N 18
extern const char *const ACH_NAMES[ACH_N];

#endif
