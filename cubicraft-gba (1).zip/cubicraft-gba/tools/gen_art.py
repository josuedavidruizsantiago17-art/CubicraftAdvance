#!/usr/bin/env python3
"""gen_art.py - convierte las texturas ORIGINALES de Cubicraft (assets/*) en datos para la GBA.

Entrada : assets/tex, assets/ico, assets/spr, assets/comp  (PNG exportados del HTML original)
Salida  : source/art.c, source/art.h  (paleta global de 240 colores + mapas de pixeles 8bpp)

Uso: python3 tools/gen_art.py
"""
import glob, os, re, sys
import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = os.path.join(ROOT, 'assets')
NCOL = 240  # indices 1..240 (0 = transparente, 241..255 = HUD)


# ----------------------------------------------------------------- enums de data.h
def enum_names(prefix):
    src = open(os.path.join(ROOT, 'source', 'data.h'), encoding='utf-8').read()
    for m in re.finditer(r'enum\s*\{(.*?)\};', src, re.S):
        names = [n.strip().split('=')[0].strip() for n in m.group(1).replace('\n', ' ').split(',')]
        names = [n for n in names if n and not n.endswith('_COUNT')]
        if names and names[0].startswith(prefix) and prefix in ('G_', 'O_', 'I_', 'M_'):
            return names
    raise SystemExit('enum no encontrado: ' + prefix)


G = enum_names('G_'); O = enum_names('O_'); I = enum_names('I_'); M = enum_names('M_')

# ids del juego original (objeto -> id)
ORIG_O = dict(TREE=1, STONE=2, COAL=3, IRON=4, DIAM=5, OBS=6, PLANK=7, COBB=8, TORCH=9, NRACK=10, DOOR=11, EXIT=12,
              NPORTAL=13, FRAME=14, FRAMEF=15, EPORTAL=16, SPAWN=17, XPORTAL=18, BED=19, RBLOCK=20, RTORCH=21,
              LEVER=22, BUTTON=23, PLATE=24, OBSERVER=25, WIRE=26, REPEATER=27, COMPARATOR=28, PISTON=29, STICKY=30,
              PHEAD=31, LAMP=32, DISPENSER=33, HOPPER=34, CHEST=35, RORE=36, CACTUS=37, PINE=38, JTREE=39, HOLE=40,
              SOIL=41, SPRINK=43, HARV=44, LAPIS=45, QORE=46, NGOLD=47, DEBRIS=48, GLOWS=49, BASALT=50, CTREE=51,
              WTREE=52, WART=53, PURPUR=54, CHORUS=55, GATE=56, ENCH=57, BREW=58, CORALR=59, CORALY=60, CORALB=61,
              CORALP=62, KELP=63, SEAGR=64, PRISM=65, SPONGE=66, GOLDB=67, WRECK=68, COBWEB=69, DSPAWN=70, TRAP=71,
              TNT=72, VAULT=73, LANTERN=74, SOULF=75, MAGMA=76)
WALLS = dict(MTN=1, CAVEW=2, NBW=3, SBW=4)

GROUND = dict(VOID='void_0', GRASS='grass_0', DIRT='dirt_0', SAND='sand_0', WATER='water_0', LAVA='lava_0',
              CAVE='cave_0', NETH='neth_0', NBF='nbf_0', END='end_0', SBF='sbf_0', PBASE='pbase_0', SNOW='snow_0',
              JGRASS='jgrass_0', PATH='path_0', WOOD='wood_0', GRASSF1='grass_1', GRASSF2='grass_2')

ITEM_ALIAS = dict(PREGEN='pt_regen_n_d', PNIGHT='pt_night_n_d', PRES='pt_res_n_d', CACTUS='blk_cactus',
                  PEARLB='pearl', BRICK='blk_door', SOULSAND='blk_soulf', TNTB='tntb', PRISMB='prismb')

MOB_TYPE = dict(COW='cow', PIG='pig', SHEEP='sheep', CHICKEN='chicken', ZOMBIE='zombie', ENDERMAN='enderman',
                BLAZE='blaze', PIGLIN='piglin', CREEPER='creeper', SKELETON='skeleton', VILLAGER='villager',
                CAT='cat', SQUID='squid')


def load(path):
    if not os.path.exists(path):
        return None
    return Image.open(path).convert('RGBA')


# ------------------------------------------------------------------ recoger imagenes
class Img:
    def __init__(self, im):
        self.im = im


images = {}  # clave -> PIL RGBA


def add(key, path, crop=False):
    im = load(path)
    if im is None:
        return None
    if crop:
        im = im.crop((1, 1, im.width - 1, im.height - 1))  # quita el contorno de 1px del original
    images[key] = im
    return key


def tex(name): return add('tex/' + name, f'{A}/tex/{name}.png')


gmap = {}
for g in G:
    n = g[2:]
    if n in GROUND:
        gmap[g] = tex('G_' + GROUND[n])
gmap['G_SOIL'] = tex('O_41_0')
water = [tex(f'G_water_{i}') for i in range(3)]
lava = [tex(f'G_lava_{i}') for i in range(3)]

omap, oalt = {}, {}
for o in O:
    n = o[2:]
    if n in ORIG_O:
        oid = ORIG_O[n]
        c0 = add(f'comp/{oid}_0', f'{A}/comp/{oid}_0.png')
        c1 = add(f'comp/{oid}_1', f'{A}/comp/{oid}_1.png')
        t0 = tex(f'O_{oid}_0')
        t1 = tex(f'O_{oid}_1')
        if n == 'RTORCH':
            omap[o], oalt[o] = c1, c0
        elif c0:
            omap[o], oalt[o] = c0, c1
        else:
            omap[o], oalt[o] = t0, t1
    elif n in WALLS:
        omap[o] = tex(f'W_{WALLS[n]}_0')
# crecimiento del trigo / zanahoria, lo demas (WELL, BRICK, ENDST, CROP...) se queda procedural

imap = {}
for it in I:
    n = it[2:].lower()
    for cand in (ITEM_ALIAS.get(n.upper()), n):
        if cand and os.path.exists(f'{A}/ico/{cand}.png'):
            imap[it] = add('ico/' + cand, f'{A}/ico/{cand}.png')
            break

mobs = {}   # (mob, view, frame) -> key
VIEW_DIR = [0, 3, 1]  # vista 0 abajo, 1 arriba, 2 lado  -> direccion original
mob_h = {}
for m in M:
    n = m[2:]
    if n not in MOB_TYPE:
        continue
    t = MOB_TYPE[n]
    for v, d in enumerate(VIEW_DIR):
        for f in range(2):
            k = add(f'spr/{t}_{d}_{f}', f'{A}/spr/{t}_{d}_{f}.png', crop=True)
            if k:
                mobs[(m, v, f)] = k
                mob_h[m] = max(mob_h.get(m, 0), images[k].height)
player = {}
for v, d in enumerate(VIEW_DIR):
    for f in range(2):
        player[(v, f)] = add(f'spr/player_{d}_{f}', f'{A}/spr/player_{d}_{f}.png', crop=True)

# --------------------------------------------------------------------- paleta global
cnt = {}
for im in images.values():
    a = np.array(im)
    msk = a[:, :, 3] >= 128
    for c in map(tuple, a[msk][:, :3] // 8 * 8 + 4):  # 5 bits por canal (formato GBA)
        cnt[c] = cnt.get(c, 0) + 1
cols = np.array(list(cnt.keys()), dtype=np.float64)
wts = np.array(list(cnt.values()), dtype=np.float64)
print('colores distintos (15 bits):', len(cols))

rng = np.random.default_rng(7)
# inicializacion k-means++ ponderada
cent = [cols[int(np.argmax(wts))]]
d2 = ((cols - cent[0]) ** 2).sum(1)
while len(cent) < NCOL:
    p = d2 * np.sqrt(wts)
    cent.append(cols[int(np.argmax(p))])
    d2 = np.minimum(d2, ((cols - cent[-1]) ** 2).sum(1))
cent = np.array(cent)
for _ in range(40):
    dist = ((cols[:, None, :] - cent[None, :, :]) ** 2).sum(2)
    lab = dist.argmin(1)
    for k in range(NCOL):
        s = lab == k
        if s.any():
            cent[k] = (cols[s] * wts[s, None]).sum(0) / wts[s].sum()
pal = np.clip(np.round(cent), 0, 255).astype(np.int32)  # 240 x 3
# ordenar por luminosidad (legibilidad del archivo)
pal = pal[np.argsort(pal @ np.array([0.3, 0.59, 0.11]))]


def nearest(rgb):
    d = ((pal[None, :, :] - rgb[:, None, :]) ** 2).sum(2)
    return d.argmin(1) + 1


def conv(im, w=None, h=None, ox=0, oy=0):
    """imagen RGBA -> bytes indexados (0 = transparente) en lienzo w x h"""
    a = np.array(im)
    w = w or im.width; h = h or im.height
    out = np.zeros((h, w), dtype=np.uint8)
    msk = a[:, :, 3] >= 128
    idx = np.zeros(a.shape[:2], dtype=np.uint8)
    if msk.any():
        idx[msk] = nearest(a[msk][:, :3].astype(np.int32))
    out[oy:oy + im.height, ox:ox + im.width] = idx
    return out.tobytes()


# ------------------------------------------------------------------- paleta antigua
# El pintor procedural (ghast, dragon, proyectiles, restos) usa P(r,s)=1+r*8+s sobre las rampas
# antiguas: se re-mapean al color mas cercano de la nueva paleta.
gfx = open(os.path.join(ROOT, 'source', 'gfx.c'), encoding='utf-8').read()
ramp_src = re.search(r'RAMP\[30\]\[6\][^=]*=\s*\{(.*?)\};', gfx, re.S).group(1)
ramps = [[int(x) for x in row.split(',') if x.strip()] for row in re.findall(r'\{([^{}]*)\}', ramp_src)]
assert len(ramps) == 30, len(ramps)
old = []
for r in range(30):
    for s in range(8):
        old.append([ramps[r][k] + (ramps[r][k + 3] - ramps[r][k]) * s // 7 for k in range(3)])
pm = [0] + [int(i) for i in nearest(np.array(old, dtype=np.int32))]

# ------------------------------------------------------------------------- blob
blob = bytearray(b'\0')  # offset 0 = "no hay"
cache = {}


def put(data):
    if data in cache:
        return cache[data]
    off = len(blob)
    blob.extend(data)
    cache[data] = off
    return off


def tile(key):
    return put(conv(images[key])) if key else 0


def sprite(key, H):
    im = images[key]
    ox = (16 - im.width) // 2
    oy = H - im.height
    return put(conv(im, 16, H, ox, oy))


# ----------------------------------------------------------------------- salida C
def arr(name, ctype, vals, per=12):
    s = f'const {ctype} {name}[{len(vals)}] = {{\n'
    for i in range(0, len(vals), per):
        s += '  ' + ', '.join(str(v) for v in vals[i:i + per]) + ',\n'
    return s + '};\n'


oG = [tile(gmap.get(g)) for g in G]
oW = [tile(k) for k in water]
oL = [tile(k) for k in lava]
oO = [tile(omap.get(o)) for o in O]
oOA = [tile(oalt.get(o)) for o in O]
oI = [tile(imap.get(i)) for i in I]
oM, mH = [], []
for m in M:
    h = mob_h.get(m, 0)
    H = 32 if h > 16 else 16
    mH.append(H if h else 0)
    for v in range(3):
        for f in range(2):
            k = mobs.get((m, v, f))
            oM.append(sprite(k, H) if k else 0)
oP = [sprite(player[(v, f)], 32) for v in range(3) for f in range(2)]

pal15 = [0] + [((int(r) >> 3) | ((int(g) >> 3) << 5) | ((int(b) >> 3) << 10)) for r, g, b in pal]

h = '''/* art.h - GENERADO por tools/gen_art.py (texturas originales de Cubicraft). No editar. */
#ifndef ART_H
#define ART_H
#include "data.h"
extern const u8 ART_BLOB[];
extern const u16 ART_PAL[241];
extern const u8 ART_PM[241];       /* indice de rampa antigua -> indice nuevo */
extern const u32 ART_G[G_COUNT], ART_W[3], ART_L[3];
extern const u32 ART_O[O_COUNT], ART_OA[O_COUNT], ART_I[I_COUNT];
extern const u32 ART_MOB[M_COUNT][3][2];  /* [mob][vista 0 abajo 1 arriba 2 lado][frame] */
extern const u8 ART_MOBH[M_COUNT];        /* 0 = procedural, 16 o 32 = alto del lienzo */
extern const u32 ART_PLAYER[3][2];        /* 16x32 */
#endif
'''
open(os.path.join(ROOT, 'source', 'art.h'), 'w').write(h)

c = '/* art.c - GENERADO por tools/gen_art.py a partir de assets/ (texturas originales). No editar. */\n#include "art.h"\n'
c += arr('ART_PAL', 'u16', pal15, 12) + arr('ART_PM', 'u8', pm, 24)
c += arr('ART_G', 'u32', oG) + arr('ART_W', 'u32', oW) + arr('ART_L', 'u32', oL)
c += arr('ART_O', 'u32', oO) + arr('ART_OA', 'u32', oOA) + arr('ART_I', 'u32', oI)
c += 'const u32 ART_MOB[M_COUNT][3][2] = {\n'
for mi in range(len(M)):
    r = oM[mi * 6:mi * 6 + 6]
    c += f'  {{{{{r[0]}, {r[1]}}}, {{{r[2]}, {r[3]}}}, {{{r[4]}, {r[5]}}}}},\n'
c += '};\n' + arr('ART_MOBH', 'u8', mH)
c += 'const u32 ART_PLAYER[3][2] = {{%d, %d}, {%d, %d}, {%d, %d}};\n' % tuple(oP)
c += 'const u8 ART_BLOB[%d] = {\n' % len(blob)
for i in range(0, len(blob), 32):
    c += '  ' + ','.join(str(b) for b in blob[i:i + 32]) + ',\n'
c += '};\n'
open(os.path.join(ROOT, 'source', 'art.c'), 'w').write(c)
print('imagenes:', len(images), ' blob:', len(blob), 'bytes; paleta:', len(pal))
print('suelos mapeados:', sum(1 for x in oG if x), '/', len(G), ' objetos:', sum(1 for x in oO if x), '/', len(O),
      ' items:', sum(1 for x in oI if x), '/', len(I), ' mobs:', [M[i] for i in range(len(M)) if mH[i]])
print('items SIN textura original:', [it for it in I if it not in imap])
print('objetos SIN textura original:', [o for o in O if o not in omap])
